The Player x Victories sets the corresponding player to have 1 victory already. This means you only need to play one round to win or lose.

The cheat uses a compare value of 0, so should only apply the 1 victory each round before the condition is no longer met and the cheat is skipped until the next round.

A time cheat should not be needed as you can disable this in the menu.