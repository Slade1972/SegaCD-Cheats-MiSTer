I used Google to translate the Japanese in this game. If some names are wrong, let me know and I'll change / fix them.

The game has a standard fighting segment and an RPG element to it as well. The cheats will make you super strong in the RPG side of the game and you will one hit kill every opponent. This only works when you start the RPG game, not the standard fighting game.

If you discover any glitches, let me know.

- Slade