It's probably best to only enable one weapon cheat at a time. The game didn't seem to crash, however, the second weapon didn't activate either.

Enable which one you want, and disable it before enabling another.

This is the same for bomb types as well. Swap between the flaming and explosive bombs.