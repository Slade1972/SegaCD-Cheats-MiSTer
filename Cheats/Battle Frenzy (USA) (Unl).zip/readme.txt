The Infinite Time cheat should be started when the countdown timer shows up on screen (just after you destroy the end of level boss), and disabled before you step back into the elevator. If you don't do it this way, the game thinks you've finished the level and skips them for you.

Yes, enabling this cheat in the elevator will skip levels for you.

- Slade