It is not recommended to run the "Have Knife" and "Have Gun" cheat simultaneously. The game only expects you to have one or the other, although they do use different addresses. This means you could easily enable both.

My guess? The game will lockup.

If you enable "Have Gun", you will need to enable the "Shots" cheat, to give you infinite shots.

"Have Knife" allows you to throw the knife over and over again.

The Snowboard levels use a different ram location for health and lives.

-Slade