This is an unlicenced and incomplete game. Refer to this website for more information: http://www.hardcoregaming101.net/citizen-x/

As such, parts of the game may not work correctly. As an example, if you enable the Flask inventory item and the M Disc, then the M Disc will sit ontop of the Flask. You can still select the Flask easily enough, you'll notice the highlight icon (the corner sections that indicate what you have selected) is bigger than the M icon by a decent amount.

If you disable a cheat, they will disappear from your inventory or revert back to their original settings.

The Ninja Health cheat is affects the Ninja character in the game. It should set his health to zero, making it one hit kill. It's not been tested properly. The game is very unstable.

Cheats with [CD PRG 2M Ram] work as normal. My software outputs two separate files, as there is no way of telling whether the game uses the Genesis 68k ram or the CD CPU ram. I test both and delete the file that doesn't work.

-Slade