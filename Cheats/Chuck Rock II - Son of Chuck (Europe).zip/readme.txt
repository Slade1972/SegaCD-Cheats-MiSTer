The Invincible cheat may cause your character to vanish throughout the game. Disable it if this occurs.
I tested it for a while and Chuck Jr stayed fully visible, however, things may not always be the same on every system. You also may have issues with the Apple Tree bonus level, in that you may not be able to hit the apples. Disable here as well.

- Slade