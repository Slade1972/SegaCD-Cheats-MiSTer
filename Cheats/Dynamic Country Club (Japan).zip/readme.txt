Max Shot Power will make you hit the ball as hard as possible. Be sure to turn it off before making shots you don't want to send flying.

- Slade