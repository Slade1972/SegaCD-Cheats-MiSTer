The Adventures of Batman and Robin uses a lot of different ram locations. The game doesn't recycle any of them between stages.

These stages are the levels between each cartoon segment. Some stages may have 3-4 levels. The cheats will work for each of the levels on that stage.  It is recommended that you only enable the correct cheats for each stage.

Fair warning - The Poison Ivy Distance Cheat for stage two only works sometimes. I found that enabling the cheat, then failing the level, often made it work second time around. At a guess, the game may use pointers for this location, and this cheat may not work every time.

The 'Short Drive' cheats should be enabled and kept enable. They work well in an emulator, but on MiSTer are a little bugged. I'm not sure why. This game does some strange things.

-Slade