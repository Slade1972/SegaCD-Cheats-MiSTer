Always Robot Mode has the benefit of making you invincible.
I had a max charge cheat, but removed it. It played havok with the game. Some weapons didn't like it and glitched completely.  It also moved each level and wasn't worth finding over and over again.

- Slade