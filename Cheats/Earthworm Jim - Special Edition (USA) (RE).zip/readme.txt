Thanks to Lee4 and Terpsfan101 for the Ammo, Health, Lives, Continues and Invincible cheats.
I tweaked Invincible to work better and found Blue Orbs, Shield, Timer and Speed for the race levels, Homing Missile, Submarine Timer and Rope Strength.

- Slade