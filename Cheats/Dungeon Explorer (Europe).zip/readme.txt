Player 1 and Player 2 may feel mixed up. Apologies for this.

If the cheats don't seem to work for you, try the other players and they should.

Enjoy this interesting spin on Gaunlet (1980's version).

- Slade