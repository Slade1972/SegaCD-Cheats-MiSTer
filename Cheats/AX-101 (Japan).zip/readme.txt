The "Always Max GPow" causes a graphical glitch in MiSTer. It doesn't affect the gameplay, however, the game may freeze if you disable this cheat.

I'm not sure what causes this behaviour, it works fine in the emulator.

-Slade