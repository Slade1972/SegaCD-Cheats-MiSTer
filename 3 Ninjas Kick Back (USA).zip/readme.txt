I wasn't aware that someone else had done some of these cheats.
Thanks to both lee4 and GameMasterZer0 on gamehacking.org for the lives, health and time cheats.

Most were redone to confirm they worked correctly.

The first person cheats need to be disabled prior to level completion / start of the next level as it can cause the game to lock up.

If you're playing two players, you will need to use the 'Two player' cheats for the first person levels (level 3 and 6). There are separate single player cheats if you are playing by yourself.

If you have any issues with cheats not working, let me know.

-Slade.